import { useEffect, useState } from "react";
import { FiTrash } from "react-icons/fi";
import { api } from "./services/api"; 


export default function App() {

useEffect (() => {
  loadCustomers()
},[])

async function loadCustomers() {
  const response = await api.get("/customers")
  console.log(response)
}

  return (
    <div className="w-full min-h-screen bg-gray-900 flex justify-center items-center px-4">
      <main className="my-10 w-full md:max-w-2xl">
        <h1 className="text-4xl font-medium text-white">Clientes</h1>

        <form className="flex flex-col my-4 text-white">
          <label className="font-medium">Nome:</label>
          <input 
            type="text"
            placeholder="Digite seu nome completo"
            className="w-full mb-5 p-2 rounded bg-gray-800 text-white" // Adicione bg-gray-800 e text-white aqui
          />
          
          <label className="font-medium">Email:</label>
          <input 
            type="email"
            placeholder="Digite seu email aqui"
            className="w-full mb-5 p-2 rounded bg-gray-800 text-white" // Adicione bg-gray-800 e text-white aqui
          />
          <input
            type="submit" 
            value="Cadastrar" 
            className="cursor-pointer w-full p-2 bg-green-500 rounded font-medium"
          />
        </form>

        <section className="flex flex-col">
          <article
            className="w-full bg-white rounded p-2 relative hover:scale-105 duration-200 mb-4"
          >
            <p><span className="font-medium">Nome:</span> Ana</p>
            <p><span className="font-medium">Email:</span> teste@gmail.com</p>
            <p><span className="font-medium">Status:</span> Ativo</p>

            <button 
              className="bg-red-500 w-7 h-7 flex items-center justify-center rounded-lg absolute right-0 -top-2"  
            >
              <FiTrash size={18} color="#fff"/>
            </button>
          </article>
        </section>
      </main>
    </div>
  );
}
